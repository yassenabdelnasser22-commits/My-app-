## Packages
@uiw/react-codemirror | Essential for the IDE code editor experience
@codemirror/lang-javascript | JavaScript language support for IDE
@codemirror/lang-html | HTML language support for IDE
@codemirror/lang-css | CSS language support for IDE
@codemirror/theme-one-dark | Dark theme to match the aesthetic
react-markdown | For rendering markdown in the Notebook feature
remark-gfm | For tables and GitHub flavored markdown support

## Notes
The application requires Replit Auth to be active.
Chat features rely on the `/api/conversations` SSE endpoints.
Make sure to install these packages before starting the dev server.
