import { Link, useLocation } from "wouter";
import { LayoutDashboard, Code2, FolderOpen, Book, MessageSquareCode, LogOut } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

const NAV_ITEMS = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/ide", label: "Code IDE", icon: Code2 },
  { href: "/files", label: "File Manager", icon: FolderOpen },
  { href: "/notebook", label: "Notebook", icon: Book },
  { href: "/assistant", label: "AI Assistant", icon: MessageSquareCode },
];

export function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  return (
    <aside className="w-64 bg-[#0a0a0a] border-r border-[#222] h-screen flex flex-col transition-all duration-300">
      <div className="p-6 border-b border-[#222]">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-primary/20 border border-primary flex items-center justify-center">
            <Code2 className="w-5 h-5 text-primary neon-text-glow" />
          </div>
          <h1 className="font-bold text-lg tracking-tight text-white">Yassen<span className="text-primary neon-text-glow">Dev</span></h1>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {NAV_ITEMS.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href} className="block">
              <div
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-lg font-medium transition-all duration-200 group cursor-pointer",
                  isActive 
                    ? "bg-primary/10 text-primary shadow-[inset_4px_0_0_0_hsl(var(--primary))]" 
                    : "text-muted-foreground hover:bg-[#1a1a1a] hover:text-white"
                )}
              >
                <Icon className={cn("w-5 h-5 transition-transform", isActive ? "scale-110" : "group-hover:scale-110")} />
                {item.label}
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-[#222]">
        <div className="flex items-center gap-3 mb-4 px-2">
          {user?.profileImageUrl ? (
            <img src={user.profileImageUrl} alt="Avatar" className="w-8 h-8 rounded-full border border-[#333]" />
          ) : (
            <div className="w-8 h-8 rounded-full bg-[#222] flex items-center justify-center text-sm font-bold">
              {user?.email?.charAt(0).toUpperCase() || "U"}
            </div>
          )}
          <div className="flex-1 overflow-hidden">
            <p className="text-sm font-medium text-white truncate">{user?.firstName || user?.email}</p>
            <p className="text-xs text-muted-foreground truncate">Developer</p>
          </div>
        </div>
        <Button 
          variant="outline" 
          className="w-full justify-start text-muted-foreground hover:text-white border-[#333] hover:border-[#555] bg-transparent hover:bg-[#1a1a1a]"
          onClick={() => logout()}
        >
          <LogOut className="w-4 h-4 mr-2" />
          Sign Out
        </Button>
      </div>
    </aside>
  );
}
