import { Code2, Terminal } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function AuthPage() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center relative overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="absolute top-[20%] left-[20%] w-96 h-96 bg-primary/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[20%] right-[20%] w-96 h-96 bg-blue-500/10 rounded-full blur-[120px] pointer-events-none" />
      
      <div className="glass-panel p-10 rounded-2xl max-w-md w-full z-10 text-center shadow-2xl relative">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent rounded-2xl pointer-events-none" />
        
        <div className="mx-auto w-16 h-16 rounded-xl bg-primary/10 border border-primary/50 flex items-center justify-center mb-8 relative">
          <div className="absolute inset-0 rounded-xl bg-primary/20 blur-md" />
          <Code2 className="w-8 h-8 text-primary relative z-10" />
        </div>
        
        <h1 className="text-3xl font-bold text-white mb-2">Welcome to <br/><span className="text-primary neon-text-glow">Yassen Develop Team</span></h1>
        <p className="text-muted-foreground mb-8">Your complete cloud-based IDE, File Manager, and AI Assistant ecosystem.</p>
        
        <Button 
          size="lg" 
          onClick={handleLogin} 
          className="w-full font-bold text-black bg-primary hover:bg-primary/90 neon-glow hover:neon-glow-strong transition-all duration-300 h-12"
        >
          <Terminal className="w-5 h-5 mr-2" />
          Login with Replit
        </Button>
        
        <p className="mt-6 text-xs text-muted-foreground">
          Secure authentication powered by Replit Auth.
        </p>
      </div>
    </div>
  );
}
