import { useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { useFiles, useDeleteFile, useCreateFile } from "@/hooks/use-files";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FolderPlus, FileText, Trash2, Search, FileCode2, Clock } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

export default function FileManager() {
  const { data: files, isLoading } = useFiles();
  const deleteFile = useDeleteFile();
  const createFile = useCreateFile();
  
  const [search, setSearch] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newFileName, setNewFileName] = useState("");

  const filteredFiles = files?.filter(f => f.name.toLowerCase().includes(search.toLowerCase()));

  const handleCreateFile = () => {
    if (!newFileName.trim()) return;
    createFile.mutate({
      name: newFileName,
      path: `/${newFileName}`,
      type: 'file',
      content: ''
    }, {
      onSuccess: () => {
        setIsDialogOpen(false);
        setNewFileName("");
      }
    });
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <main className="flex-1 bg-[#0f0f0f] overflow-y-auto p-8">
        <header className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">File Manager</h1>
            <p className="text-muted-foreground text-sm">Manage all your workspace files and assets.</p>
          </div>
          
          <div className="flex gap-4">
            <div className="relative w-64">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input 
                placeholder="Search files..." 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 bg-[#1a1a1a] border-[#333] focus-visible:ring-primary text-white"
              />
            </div>
            
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-primary text-black hover:bg-primary/90 font-semibold neon-glow">
                  <FolderPlus className="w-4 h-4 mr-2" />
                  New File
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-[#111] border-[#333] text-white">
                <DialogHeader>
                  <DialogTitle>Create a File</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <Input 
                    placeholder="Filename (e.g. document.txt)" 
                    value={newFileName}
                    onChange={(e) => setNewFileName(e.target.value)}
                    className="bg-[#222] border-[#444] text-white focus-visible:ring-primary"
                    onKeyDown={(e) => e.key === 'Enter' && handleCreateFile()}
                  />
                  <Button 
                    onClick={handleCreateFile}
                    disabled={createFile.isPending || !newFileName}
                    className="w-full bg-primary text-black hover:bg-primary/90"
                  >
                    {createFile.isPending ? "Creating..." : "Create"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </header>

        {isLoading ? (
          <div className="text-center py-20 text-muted-foreground">Loading files...</div>
        ) : filteredFiles?.length === 0 ? (
          <div className="text-center py-20 flex flex-col items-center justify-center border-2 border-dashed border-[#333] rounded-2xl">
            <FileText className="w-16 h-16 text-[#444] mb-4" />
            <p className="text-lg text-white font-medium mb-1">No files found</p>
            <p className="text-muted-foreground">Create a new file to get started.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredFiles?.map(file => (
              <Card key={file.id} className="bg-[#161616] border-[#222] hover:border-primary/50 transition-all duration-300 group">
                <div className="p-5 flex flex-col h-full">
                  <div className="flex justify-between items-start mb-4">
                    <div className="p-3 bg-[#222] rounded-xl group-hover:bg-primary/10 transition-colors">
                      <FileCode2 className="w-6 h-6 text-gray-400 group-hover:text-primary transition-colors" />
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => {
                        if (confirm(`Are you sure you want to delete ${file.name}?`)) {
                          deleteFile.mutate(file.id);
                        }
                      }}
                      className="text-gray-500 hover:text-red-500 hover:bg-red-500/10 opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <h3 className="font-semibold text-white mb-1 truncate" title={file.name}>{file.name}</h3>
                  <div className="mt-auto pt-4 flex items-center text-xs text-muted-foreground gap-1.5">
                    <Clock className="w-3.5 h-3.5" />
                    {new Date(file.updatedAt).toLocaleDateString()}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
