import { useState, useRef, useEffect } from "react";
import { Sidebar } from "@/components/Sidebar";
import { useConversations, useCreateConversation, useDeleteConversation, useConversation, useChatStream } from "@/hooks/use-chat";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageSquare, Send, Plus, Trash2, Bot, User } from "lucide-react";
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

export default function AIAssistant() {
  const { data: conversations, isLoading } = useConversations();
  const createConversation = useCreateConversation();
  const deleteConversation = useDeleteConversation();

  const [activeConvId, setActiveConvId] = useState<number | null>(null);
  const { data: activeConversation } = useConversation(activeConvId);
  const { sendMessage, isStreaming, streamingContent } = useChatStream(activeConvId);
  
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [activeConversation?.messages, streamingContent]);

  const handleCreateNew = () => {
    createConversation.mutate("New Conversation", {
      onSuccess: (data) => setActiveConvId(data.id)
    });
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isStreaming || !activeConvId) return;
    
    sendMessage(input);
    setInput("");
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[#0f0f0f]">
      <Sidebar />
      
      {/* History Sidebar */}
      <div className="w-72 bg-[#111] border-r border-[#222] flex flex-col">
        <div className="p-4 border-b border-[#222] flex items-center justify-between">
          <h2 className="font-bold text-white flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-primary" />
            AI Chats
          </h2>
          <Button 
            size="icon" 
            variant="ghost" 
            onClick={handleCreateNew}
            disabled={createConversation.isPending}
            className="h-8 w-8 text-primary hover:bg-primary/20 hover:text-primary"
          >
            <Plus className="w-4 h-4" />
          </Button>
        </div>

        <ScrollArea className="flex-1 p-3">
          {isLoading ? (
            <div className="text-center text-sm text-muted-foreground mt-4">Loading...</div>
          ) : conversations?.length === 0 ? (
            <div className="text-center text-sm text-muted-foreground mt-4">No past conversations.</div>
          ) : (
            <div className="space-y-2">
              {conversations?.map(conv => (
                <div 
                  key={conv.id}
                  onClick={() => setActiveConvId(conv.id)}
                  className={`p-3 rounded-lg cursor-pointer transition-all border flex items-center justify-between group ${
                    activeConvId === conv.id 
                      ? "bg-primary/10 border-primary/30 text-primary" 
                      : "bg-[#1a1a1a] border-transparent hover:border-[#333] text-gray-300"
                  }`}
                >
                  <span className="truncate text-sm font-medium">{conv.title}</span>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      if (confirm("Delete conversation?")) deleteConversation.mutate(conv.id);
                    }}
                    className="text-gray-500 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col relative">
        {activeConvId ? (
          <>
            <div className="h-16 border-b border-[#222] flex items-center px-6 bg-[#161616]">
              <h3 className="font-semibold text-white">{activeConversation?.title || "Loading..."}</h3>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6" ref={scrollRef}>
              {activeConversation?.messages?.map((msg, i) => (
                <div key={i} className={`flex gap-4 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  {msg.role === 'assistant' && (
                    <div className="w-8 h-8 rounded-full bg-primary/20 border border-primary flex items-center justify-center shrink-0">
                      <Bot className="w-4 h-4 text-primary" />
                    </div>
                  )}
                  
                  <div className={`max-w-[80%] rounded-2xl px-5 py-3 ${
                    msg.role === 'user' 
                      ? 'bg-primary text-black ml-auto rounded-tr-sm' 
                      : 'bg-[#222] border border-[#333] text-gray-200 rounded-tl-sm'
                  }`}>
                    {msg.role === 'user' ? (
                      <p className="whitespace-pre-wrap text-sm font-medium">{msg.content}</p>
                    ) : (
                      <div className="prose prose-invert prose-sm max-w-none prose-p:leading-relaxed prose-pre:bg-[#111] prose-pre:border prose-pre:border-[#333]">
                        <ReactMarkdown remarkPlugins={[remarkGfm]}>{msg.content}</ReactMarkdown>
                      </div>
                    )}
                  </div>
                  
                  {msg.role === 'user' && (
                    <div className="w-8 h-8 rounded-full bg-[#333] flex items-center justify-center shrink-0">
                      <User className="w-4 h-4 text-gray-400" />
                    </div>
                  )}
                </div>
              ))}

              {isStreaming && streamingContent && (
                <div className="flex gap-4 justify-start">
                  <div className="w-8 h-8 rounded-full bg-primary/20 border border-primary flex items-center justify-center shrink-0">
                    <Bot className="w-4 h-4 text-primary" />
                  </div>
                  <div className="max-w-[80%] rounded-2xl px-5 py-3 bg-[#222] border border-[#333] text-gray-200 rounded-tl-sm">
                    <div className="prose prose-invert prose-sm max-w-none prose-p:leading-relaxed">
                      <ReactMarkdown remarkPlugins={[remarkGfm]}>{streamingContent}</ReactMarkdown>
                    </div>
                  </div>
                </div>
              )}
              
              {isStreaming && !streamingContent && (
                <div className="flex gap-4 justify-start">
                  <div className="w-8 h-8 rounded-full bg-primary/20 border border-primary flex items-center justify-center shrink-0 animate-pulse">
                    <Bot className="w-4 h-4 text-primary" />
                  </div>
                  <div className="max-w-[80%] rounded-2xl px-5 py-4 bg-[#222] border border-[#333] flex items-center gap-1">
                    <div className="w-2 h-2 rounded-full bg-primary animate-bounce" />
                    <div className="w-2 h-2 rounded-full bg-primary animate-bounce delay-75" />
                    <div className="w-2 h-2 rounded-full bg-primary animate-bounce delay-150" />
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 bg-[#161616] border-t border-[#222]">
              <form onSubmit={handleSend} className="max-w-4xl mx-auto relative">
                <Input 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask the AI assistant for coding help..."
                  className="w-full bg-[#222] border-[#333] text-white pl-4 pr-12 py-6 rounded-xl focus-visible:ring-primary shadow-inner"
                  disabled={isStreaming}
                />
                <Button 
                  type="submit" 
                  size="icon"
                  disabled={!input.trim() || isStreaming}
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8 bg-primary text-black hover:bg-primary/90 transition-transform hover:scale-105"
                >
                  <Send className="w-4 h-4 ml-0.5" />
                </Button>
              </form>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground">
            <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-6">
              <Bot className="w-10 h-10 text-primary" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">AI Coding Assistant</h3>
            <p className="max-w-md text-center">Select an existing conversation or create a new one to get help with code, debugging, and architecture.</p>
            <Button 
              onClick={handleCreateNew} 
              className="mt-6 bg-primary text-black hover:bg-primary/90 font-bold neon-glow"
            >
              Start New Chat
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
