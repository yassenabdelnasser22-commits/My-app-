import { Sidebar } from "@/components/Sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useFiles } from "@/hooks/use-files";
import { useNotes } from "@/hooks/use-notes";
import { useConversations } from "@/hooks/use-chat";
import { Code2, FolderOpen, Book, MessageSquareCode, Activity } from "lucide-react";

export default function Dashboard() {
  const { data: files } = useFiles();
  const { data: notes } = useNotes();
  const { data: conversations } = useConversations();

  const stats = [
    { label: "Total Files", value: files?.length || 0, icon: FolderOpen, color: "text-blue-400", bg: "bg-blue-400/10" },
    { label: "Saved Notes", value: notes?.length || 0, icon: Book, color: "text-yellow-400", bg: "bg-yellow-400/10" },
    { label: "AI Chats", value: conversations?.length || 0, icon: MessageSquareCode, color: "text-primary", bg: "bg-primary/10" },
  ];

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <main className="flex-1 bg-[#0f0f0f] overflow-y-auto p-8">
        <header className="mb-10">
          <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-2">
            <Activity className="w-8 h-8 text-primary" />
            Dashboard Overview
          </h1>
          <p className="text-muted-foreground">Welcome back. Here's a summary of your workspace.</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          {stats.map((stat, i) => {
            const Icon = stat.icon;
            return (
              <Card key={i} className="bg-[#161616] border-[#222] hover:border-primary/50 transition-colors duration-300">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">{stat.label}</CardTitle>
                  <div className={`p-2 rounded-lg ${stat.bg}`}>
                    <Icon className={`w-5 h-5 ${stat.color}`} />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold text-white">{stat.value}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card className="bg-[#161616] border-[#222]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-white">
                <Code2 className="w-5 h-5 text-primary" />
                Recent Files
              </CardTitle>
            </CardHeader>
            <CardContent>
              {files?.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">No files yet. Start coding!</div>
              ) : (
                <div className="space-y-4">
                  {files?.slice(0, 5).map((f) => (
                    <div key={f.id} className="flex justify-between items-center p-3 rounded-lg bg-[#222] hover:bg-[#2a2a2a] transition-colors cursor-pointer">
                      <div className="flex items-center gap-3">
                        <Code2 className="w-4 h-4 text-blue-400" />
                        <span className="font-medium text-sm text-gray-200">{f.name}</span>
                      </div>
                      <span className="text-xs text-muted-foreground">{new Date(f.updatedAt).toLocaleDateString()}</span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="bg-[#161616] border-[#222]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-white">
                <Book className="w-5 h-5 text-yellow-400" />
                Recent Notes
              </CardTitle>
            </CardHeader>
            <CardContent>
              {notes?.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">No notes yet. Jot something down!</div>
              ) : (
                <div className="space-y-4">
                  {notes?.slice(0, 5).map((n) => (
                    <div key={n.id} className="flex justify-between items-center p-3 rounded-lg bg-[#222] hover:bg-[#2a2a2a] transition-colors cursor-pointer">
                      <div className="flex items-center gap-3">
                        <Book className="w-4 h-4 text-yellow-400" />
                        <span className="font-medium text-sm text-gray-200 truncate max-w-[200px]">{n.title}</span>
                      </div>
                      <span className="text-xs text-muted-foreground">{new Date(n.updatedAt).toLocaleDateString()}</span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
