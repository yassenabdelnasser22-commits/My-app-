import { useState, useEffect } from "react";
import { Sidebar } from "@/components/Sidebar";
import { useNotes, useCreateNote, useUpdateNote, useDeleteNote } from "@/hooks/use-notes";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Plus, Trash2, Edit3, Eye, BookOpen, Save } from "lucide-react";
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

export default function Notebook() {
  const { data: notes, isLoading } = useNotes();
  const createNote = useCreateNote();
  const updateNote = useUpdateNote();
  const deleteNote = useDeleteNote();

  const [activeNoteId, setActiveNoteId] = useState<number | null>(null);
  const [isPreview, setIsPreview] = useState(false);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  const activeNote = notes?.find(n => n.id === activeNoteId);

  useEffect(() => {
    if (activeNote) {
      setTitle(activeNote.title);
      setContent(activeNote.content);
    } else {
      setTitle("");
      setContent("");
    }
  }, [activeNoteId, notes]);

  const handleCreateNew = () => {
    createNote.mutate({
      title: "Untitled Note",
      content: "# New Note\n\nStart typing here..."
    }, {
      onSuccess: (data) => {
        setActiveNoteId(data.id);
        setIsPreview(false);
      }
    });
  };

  const handleSave = () => {
    if (!activeNoteId) return;
    updateNote.mutate({
      id: activeNoteId,
      title,
      content
    });
  };

  const handleDelete = (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm("Delete this note?")) {
      deleteNote.mutate(id, {
        onSuccess: () => {
          if (activeNoteId === id) setActiveNoteId(null);
        }
      });
    }
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      {/* Note List Sidebar */}
      <div className="w-72 bg-[#111] border-r border-[#222] flex flex-col">
        <div className="p-4 border-b border-[#222] flex items-center justify-between">
          <h2 className="font-bold text-white flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-primary" />
            My Notes
          </h2>
          <Button 
            size="icon" 
            variant="ghost" 
            onClick={handleCreateNew}
            disabled={createNote.isPending}
            className="h-8 w-8 text-primary hover:bg-primary/20 hover:text-primary"
          >
            <Plus className="w-4 h-4" />
          </Button>
        </div>

        <ScrollArea className="flex-1 p-3">
          {isLoading ? (
            <div className="text-center text-sm text-muted-foreground mt-4">Loading notes...</div>
          ) : notes?.length === 0 ? (
            <div className="text-center text-sm text-muted-foreground mt-4">No notes created.</div>
          ) : (
            <div className="space-y-2">
              {notes?.map(note => (
                <div 
                  key={note.id}
                  onClick={() => setActiveNoteId(note.id)}
                  className={`p-3 rounded-lg cursor-pointer transition-all border ${
                    activeNoteId === note.id 
                      ? "bg-primary/10 border-primary/30" 
                      : "bg-[#1a1a1a] border-transparent hover:border-[#333]"
                  }`}
                >
                  <div className="flex justify-between items-start mb-1">
                    <h3 className={`font-medium text-sm truncate pr-2 ${activeNoteId === note.id ? "text-primary" : "text-white"}`}>
                      {note.title || "Untitled"}
                    </h3>
                    <button 
                      onClick={(e) => handleDelete(note.id, e)}
                      className="text-gray-500 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p className="text-xs text-muted-foreground truncate">{note.content.replace(/[#*]/g, '')}</p>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </div>

      {/* Editor Area */}
      <div className="flex-1 bg-[#0f0f0f] flex flex-col">
        {activeNote ? (
          <>
            <div className="h-16 border-b border-[#222] flex items-center justify-between px-6 bg-[#161616]">
              <Input 
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="max-w-md bg-transparent border-none text-xl font-bold text-white focus-visible:ring-0 px-0 h-auto"
                placeholder="Note Title"
              />
              <div className="flex items-center gap-3">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setIsPreview(!isPreview)}
                  className="border-[#333] text-gray-300 hover:text-white hover:bg-[#222]"
                >
                  {isPreview ? <Edit3 className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
                  {isPreview ? "Edit Mode" : "Preview"}
                </Button>
                <Button 
                  size="sm"
                  onClick={handleSave}
                  disabled={updateNote.isPending}
                  className="bg-primary text-black hover:bg-primary/90 font-semibold"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {updateNote.isPending ? "Saving..." : "Save Note"}
                </Button>
              </div>
            </div>

            <div className="flex-1 overflow-auto p-6">
              {isPreview ? (
                <div className="prose prose-invert prose-p:text-gray-300 prose-headings:text-white prose-a:text-primary max-w-4xl mx-auto">
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>
                    {content || "*No content yet*"}
                  </ReactMarkdown>
                </div>
              ) : (
                <Textarea 
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Write your markdown here..."
                  className="w-full h-full min-h-[500px] bg-transparent border-none resize-none focus-visible:ring-0 text-gray-300 font-mono text-sm leading-relaxed p-0"
                />
              )}
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground">
            <BookOpen className="w-16 h-16 mb-4 text-[#333]" />
            <p>Select a note from the sidebar or create a new one.</p>
          </div>
        )}
      </div>
    </div>
  );
}
