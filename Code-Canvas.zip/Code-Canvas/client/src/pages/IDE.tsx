import { useState, useEffect } from "react";
import { Sidebar } from "@/components/Sidebar";
import { useFiles, useCreateFile, useUpdateFile } from "@/hooks/use-files";
import CodeMirror from '@uiw/react-codemirror';
import { javascript } from '@codemirror/lang-javascript';
import { html } from '@codemirror/lang-html';
import { css } from '@codemirror/lang-css';
import { oneDark } from '@codemirror/theme-one-dark';
import { FileCode2, Plus, Save, TerminalSquare, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function IDE() {
  const { data: files, isLoading } = useFiles();
  const createFile = useCreateFile();
  const updateFile = useUpdateFile();
  
  const [activeFileId, setActiveFileId] = useState<number | null>(null);
  const [code, setCode] = useState("");
  const [newFileName, setNewFileName] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const activeFile = files?.find(f => f.id === activeFileId);

  useEffect(() => {
    if (activeFile) {
      setCode(activeFile.content || "");
    } else {
      setCode("");
    }
  }, [activeFileId]);

  const handleCreateFile = () => {
    if (!newFileName.trim()) return;
    
    // Determine type from extension or default to js
    let type = "javascript";
    if (newFileName.endsWith(".html")) type = "html";
    if (newFileName.endsWith(".css")) type = "css";

    createFile.mutate({
      name: newFileName,
      path: `/${newFileName}`,
      type: 'file',
      content: `// New file: ${newFileName}\n`
    }, {
      onSuccess: (data) => {
        setIsDialogOpen(false);
        setNewFileName("");
        setActiveFileId(data.id);
      }
    });
  };

  const handleSave = () => {
    if (!activeFileId) return;
    updateFile.mutate({ id: activeFileId, content: code });
  };

  const getLanguageExtension = (filename: string) => {
    if (filename.endsWith('.html')) return html();
    if (filename.endsWith('.css')) return css();
    return javascript();
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      {/* File Explorer */}
      <div className="w-64 bg-[#0d0d0d] border-r border-[#222] flex flex-col">
        <div className="p-4 border-b border-[#222] flex items-center justify-between">
          <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Explorer</span>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="ghost" size="icon" className="h-6 w-6 hover:bg-[#222] text-muted-foreground hover:text-white">
                <Plus className="w-4 h-4" />
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-[#111] border-[#333] text-white">
              <DialogHeader>
                <DialogTitle>Create New File</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <Input 
                  placeholder="e.g. index.js, styles.css" 
                  value={newFileName}
                  onChange={(e) => setNewFileName(e.target.value)}
                  className="bg-[#222] border-[#444] focus-visible:ring-primary text-white"
                  onKeyDown={(e) => e.key === 'Enter' && handleCreateFile()}
                />
                <Button 
                  onClick={handleCreateFile} 
                  disabled={createFile.isPending || !newFileName}
                  className="w-full bg-primary text-black hover:bg-primary/90"
                >
                  {createFile.isPending ? "Creating..." : "Create File"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <ScrollArea className="flex-1">
          <div className="p-2 space-y-1">
            {isLoading ? (
              <div className="text-xs text-center text-muted-foreground py-4">Loading workspace...</div>
            ) : files?.length === 0 ? (
              <div className="text-xs text-center text-muted-foreground py-4 px-2">Workspace empty. Create a file to begin.</div>
            ) : (
              files?.map(file => (
                <button
                  key={file.id}
                  onClick={() => setActiveFileId(file.id)}
                  className={`w-full flex items-center gap-2 px-3 py-1.5 rounded text-sm transition-colors ${
                    activeFileId === file.id 
                      ? "bg-primary/10 text-primary" 
                      : "text-gray-400 hover:bg-[#222] hover:text-gray-200"
                  }`}
                >
                  <FileCode2 className={`w-4 h-4 ${activeFileId === file.id ? "text-primary" : "text-gray-500"}`} />
                  <span className="truncate">{file.name}</span>
                </button>
              ))
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Editor Area */}
      <div className="flex-1 flex flex-col bg-[#1e1e1e]">
        {activeFile ? (
          <>
            <div className="h-10 bg-[#161616] border-b border-[#222] flex items-center justify-between px-4">
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <FileCode2 className="w-4 h-4 text-primary" />
                {activeFile.name}
              </div>
              <Button 
                size="sm" 
                variant="ghost" 
                className="h-7 text-xs text-primary hover:text-primary hover:bg-primary/10"
                onClick={handleSave}
                disabled={updateFile.isPending}
              >
                <Save className="w-3 h-3 mr-1.5" />
                {updateFile.isPending ? "Saving..." : "Save (Ctrl+S)"}
              </Button>
            </div>
            <div className="flex-1 overflow-auto relative custom-editor-wrapper">
              <CodeMirror
                value={code}
                height="100%"
                theme={oneDark}
                extensions={[getLanguageExtension(activeFile.name)]}
                onChange={(val) => setCode(val)}
                className="h-full text-sm font-mono"
                basicSetup={{
                  lineNumbers: true,
                  highlightActiveLineGutter: true,
                  foldGutter: true,
                }}
              />
            </div>
            
            {/* Terminal Mock Footer */}
            <div className="h-8 bg-[#111] border-t border-[#222] flex items-center px-4 text-xs text-muted-foreground gap-4">
              <span className="flex items-center gap-1.5"><TerminalSquare className="w-3.5 h-3.5"/> Terminal Ready</span>
              <span className="flex items-center gap-1.5 text-primary"><AlertCircle className="w-3.5 h-3.5"/> 0 Errors</span>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-muted-foreground flex-col gap-4">
            <Code2 className="w-16 h-16 text-[#333]" />
            <p>Select a file from the explorer or create a new one.</p>
          </div>
        )}
      </div>
    </div>
  );
}
