import { sql } from "drizzle-orm";
import { pgTable, text, serial, integer, timestamp, varchar, boolean } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// --- Auth Tables (Required for Replit Auth) ---
export * from "./models/auth";

// --- Chat Tables (Required for AI Chat) ---
export * from "./models/chat";

// --- Application Tables ---

export const files = pgTable("files", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  path: text("path").notNull(),
  type: text("type").notNull(), // 'folder' | 'file'
  content: text("content"), // for text/code files
  parentId: integer("parent_id"), // null for root level
  userId: varchar("user_id").notNull(), // User who owns this file
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const notes = pgTable("notes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  userId: varchar("user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// --- Relations ---

export const filesRelations = relations(files, ({ one, many }) => ({
  parent: one(files, {
    fields: [files.parentId],
    references: [files.id],
    relationName: "folder_contents"
  }),
  children: many(files, { relationName: "folder_contents" }),
}));

// --- Schemas ---

export const insertFileSchema = createInsertSchema(files).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});

export const insertNoteSchema = createInsertSchema(notes).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

// --- Types ---

export type File = typeof files.$inferSelect;
export type InsertFile = z.infer<typeof insertFileSchema>;

export type Note = typeof notes.$inferSelect;
export type InsertNote = z.infer<typeof insertNoteSchema>;

// API Contract Types

export type CreateFileRequest = Omit<InsertFile, 'userId'>; // userId set by server
export type UpdateFileRequest = Partial<Omit<InsertFile, 'userId'>>;

export type CreateNoteRequest = Omit<InsertNote, 'userId'>;
export type UpdateNoteRequest = Partial<Omit<InsertNote, 'userId'>>;
