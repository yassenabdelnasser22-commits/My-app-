import { z } from "zod";
import { insertFileSchema, insertNoteSchema } from "./schema";

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

// Frontend expects schemas without the auto-generated userId for creation
const createFileSchema = insertFileSchema.omit({ userId: true });
const updateFileSchema = insertFileSchema.omit({ userId: true }).partial();

const createNoteSchema = insertNoteSchema.omit({ userId: true });
const updateNoteSchema = insertNoteSchema.omit({ userId: true }).partial();

export const api = {
  files: {
    list: {
      method: "GET" as const,
      path: "/api/files" as const,
      input: z.object({
        parentId: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.any()), // typing avoided for brevity, matches File
        401: errorSchemas.unauthorized,
      },
    },
    get: {
      method: "GET" as const,
      path: "/api/files/:id" as const,
      responses: {
        200: z.any(),
        401: errorSchemas.unauthorized,
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: "POST" as const,
      path: "/api/files" as const,
      input: createFileSchema,
      responses: {
        201: z.any(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    update: {
      method: "PUT" as const,
      path: "/api/files/:id" as const,
      input: updateFileSchema,
      responses: {
        200: z.any(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: "DELETE" as const,
      path: "/api/files/:id" as const,
      responses: {
        204: z.void(),
        401: errorSchemas.unauthorized,
        404: errorSchemas.notFound,
      },
    },
  },
  notes: {
    list: {
      method: "GET" as const,
      path: "/api/notes" as const,
      responses: {
        200: z.array(z.any()),
        401: errorSchemas.unauthorized,
      },
    },
    get: {
      method: "GET" as const,
      path: "/api/notes/:id" as const,
      responses: {
        200: z.any(),
        401: errorSchemas.unauthorized,
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: "POST" as const,
      path: "/api/notes" as const,
      input: createNoteSchema,
      responses: {
        201: z.any(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    update: {
      method: "PUT" as const,
      path: "/api/notes/:id" as const,
      input: updateNoteSchema,
      responses: {
        200: z.any(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: "DELETE" as const,
      path: "/api/notes/:id" as const,
      responses: {
        204: z.void(),
        401: errorSchemas.unauthorized,
        404: errorSchemas.notFound,
      },
    },
  },
  // The Replit Auth and Chat integrations handle their own routes.
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type FileInput = z.infer<typeof api.files.create.input>;
export type FileUpdateInput = z.infer<typeof api.files.update.input>;
export type NoteInput = z.infer<typeof api.notes.create.input>;
export type NoteUpdateInput = z.infer<typeof api.notes.update.input>;
