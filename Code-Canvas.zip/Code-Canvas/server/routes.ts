import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api, errorSchemas } from "@shared/routes";
import { z } from "zod";
import { isAuthenticated, registerAuthRoutes } from "./replit_integrations/auth";
import { registerChatRoutes } from "./replit_integrations/chat";
import { registerAudioRoutes } from "./replit_integrations/audio";
import { registerImageRoutes } from "./replit_integrations/image";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Register integration routes
  registerAuthRoutes(app);
  registerChatRoutes(app);
  registerAudioRoutes(app);
  registerImageRoutes(app);

  // Files
  app.get(api.files.list.path, isAuthenticated, async (req: any, res) => {
    try {
      const parentId = req.query.parentId ? Number(req.query.parentId) : undefined;
      const files = await storage.getFiles(req.user.claims.sub, parentId);
      res.json(files);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch files" });
    }
  });

  app.get(api.files.get.path, isAuthenticated, async (req: any, res) => {
    try {
      const file = await storage.getFile(Number(req.params.id), req.user.claims.sub);
      if (!file) {
        return res.status(404).json(errorSchemas.notFound.parse({ message: "File not found" }));
      }
      res.json(file);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch file" });
    }
  });

  app.post(api.files.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.files.create.input.parse(req.body);
      const file = await storage.createFile(input, req.user.claims.sub);
      res.status(201).json(file);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json(errorSchemas.validation.parse({
          message: err.errors[0].message,
          field: err.errors[0].path.join("."),
        }));
      }
      res.status(500).json({ message: "Failed to create file" });
    }
  });

  app.put(api.files.update.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.files.update.input.parse(req.body);
      const file = await storage.updateFile(Number(req.params.id), input, req.user.claims.sub);
      res.json(file);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json(errorSchemas.validation.parse({
          message: err.errors[0].message,
          field: err.errors[0].path.join("."),
        }));
      }
      res.status(500).json({ message: "Failed to update file" });
    }
  });

  app.delete(api.files.delete.path, isAuthenticated, async (req: any, res) => {
    try {
      await storage.deleteFile(Number(req.params.id), req.user.claims.sub);
      res.status(204).send();
    } catch (err) {
      res.status(500).json({ message: "Failed to delete file" });
    }
  });

  // Notes
  app.get(api.notes.list.path, isAuthenticated, async (req: any, res) => {
    try {
      const notes = await storage.getNotes(req.user.claims.sub);
      res.json(notes);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch notes" });
    }
  });

  app.get(api.notes.get.path, isAuthenticated, async (req: any, res) => {
    try {
      const note = await storage.getNote(Number(req.params.id), req.user.claims.sub);
      if (!note) {
        return res.status(404).json(errorSchemas.notFound.parse({ message: "Note not found" }));
      }
      res.json(note);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch note" });
    }
  });

  app.post(api.notes.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.notes.create.input.parse(req.body);
      const note = await storage.createNote(input, req.user.claims.sub);
      res.status(201).json(note);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json(errorSchemas.validation.parse({
          message: err.errors[0].message,
          field: err.errors[0].path.join("."),
        }));
      }
      res.status(500).json({ message: "Failed to create note" });
    }
  });

  app.put(api.notes.update.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.notes.update.input.parse(req.body);
      const note = await storage.updateNote(Number(req.params.id), input, req.user.claims.sub);
      res.json(note);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json(errorSchemas.validation.parse({
          message: err.errors[0].message,
          field: err.errors[0].path.join("."),
        }));
      }
      res.status(500).json({ message: "Failed to update note" });
    }
  });

  app.delete(api.notes.delete.path, isAuthenticated, async (req: any, res) => {
    try {
      await storage.deleteNote(Number(req.params.id), req.user.claims.sub);
      res.status(204).send();
    } catch (err) {
      res.status(500).json({ message: "Failed to delete note" });
    }
  });

  return httpServer;
}
