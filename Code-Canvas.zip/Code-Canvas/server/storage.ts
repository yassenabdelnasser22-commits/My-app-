import { files, notes, type File, type Note, type CreateFileRequest, type UpdateFileRequest, type CreateNoteRequest, type UpdateNoteRequest } from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // Files
  getFiles(userId: string, parentId?: number | null): Promise<File[]>;
  getFile(id: number, userId: string): Promise<File | undefined>;
  createFile(file: CreateFileRequest, userId: string): Promise<File>;
  updateFile(id: number, updates: UpdateFileRequest, userId: string): Promise<File>;
  deleteFile(id: number, userId: string): Promise<void>;

  // Notes
  getNotes(userId: string): Promise<Note[]>;
  getNote(id: number, userId: string): Promise<Note | undefined>;
  createNote(note: CreateNoteRequest, userId: string): Promise<Note>;
  updateNote(id: number, updates: UpdateNoteRequest, userId: string): Promise<Note>;
  deleteNote(id: number, userId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Files
  async getFiles(userId: string, parentId?: number | null): Promise<File[]> {
    if (parentId !== undefined) {
      return await db.select().from(files).where(and(eq(files.userId, userId), parentId === null ? eq(files.parentId, null as any) : eq(files.parentId, parentId)));
    }
    return await db.select().from(files).where(eq(files.userId, userId));
  }

  async getFile(id: number, userId: string): Promise<File | undefined> {
    const [file] = await db.select().from(files).where(and(eq(files.id, id), eq(files.userId, userId)));
    return file;
  }

  async createFile(file: CreateFileRequest, userId: string): Promise<File> {
    const [created] = await db.insert(files).values({ ...file, userId }).returning();
    return created;
  }

  async updateFile(id: number, updates: UpdateFileRequest, userId: string): Promise<File> {
    const [updated] = await db.update(files)
      .set({ ...updates, updatedAt: new Date() })
      .where(and(eq(files.id, id), eq(files.userId, userId)))
      .returning();
    return updated;
  }

  async deleteFile(id: number, userId: string): Promise<void> {
    await db.delete(files).where(and(eq(files.id, id), eq(files.userId, userId)));
  }

  // Notes
  async getNotes(userId: string): Promise<Note[]> {
    return await db.select().from(notes).where(eq(notes.userId, userId));
  }

  async getNote(id: number, userId: string): Promise<Note | undefined> {
    const [note] = await db.select().from(notes).where(and(eq(notes.id, id), eq(notes.userId, userId)));
    return note;
  }

  async createNote(note: CreateNoteRequest, userId: string): Promise<Note> {
    const [created] = await db.insert(notes).values({ ...note, userId }).returning();
    return created;
  }

  async updateNote(id: number, updates: UpdateNoteRequest, userId: string): Promise<Note> {
    const [updated] = await db.update(notes)
      .set({ ...updates, updatedAt: new Date() })
      .where(and(eq(notes.id, id), eq(notes.userId, userId)))
      .returning();
    return updated;
  }

  async deleteNote(id: number, userId: string): Promise<void> {
    await db.delete(notes).where(and(eq(notes.id, id), eq(notes.userId, userId)));
  }
}

export const storage = new DatabaseStorage();
